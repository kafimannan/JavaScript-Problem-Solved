console.log("Select an option :\n1. Add \n2. Substract \n3. multiply \n4. Divide");

var num1 = prompt ("Enter 1st number");
var num2 = prompt ("Enter 2nd number");
var option = prompt ("Choose an option:");
var result = null;

num1 = parseInt(num1);
num2 = parseInt(num2);
option = parseInt(option);

var num1con = isNaN(num1); 
var num2con = isNaN(num2); 
var optionCon = isNaN(option); 

if (num1con || num2con || optionCon ) {
    console.log("Invalid Input!");
}
else {
    switch(option){
        case 1:
            result = num1 + num2;
            break;
            case 2:
                result = num1 - num2;
                break;
                case 3:
                    result = num1 * num2;
                    break;
                    case 4:
                        result = num1 / num2;
                        break;
               default:
                   break;         
    }


    if (result == null) {
        console.log("NO Result");
    }
    else {
        console.log("Result: " + result);
    }
}

 
