var n = parseInt(prompt ("Enter 1st number"));
var sum = 0;
var serries = "";

for(var i = 1; i <=n; i++){
    sum += i**2;
    serries +=(i **2).toString();
    if(i ==n) {continue;}
    serries += "+";

}
console.log(`${serries} = ${sum}`);