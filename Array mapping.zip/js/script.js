// array iteration usig Mapping
var car = ["BMW", "TOyta","Ferrrary"];
function addSomething(item){
    return `${item} is a new model`;

}
let arr_res = car.map(addSomething);
console.log(arr_res);