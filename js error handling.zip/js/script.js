console.log('Before Error');
try {
    test();
} catch (error) {
    // console.log(error);
    console.log(error.message);
}

console.log('After Error');